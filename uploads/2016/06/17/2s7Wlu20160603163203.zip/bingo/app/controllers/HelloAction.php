<?php
/**
 * User: toozy <toozy@foxmail.com>
 * Date: 13-7-9
 * Time: 下午2:37
 */
class HelloAction extends Action{
    public function __construct(){
        $this->_hasView = 0;
    }
    protected function _main(){
        echo 'hello world';
    }
}