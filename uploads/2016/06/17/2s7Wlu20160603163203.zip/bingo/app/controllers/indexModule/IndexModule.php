<?php
/**
 * User: toozy <toozy@foxmail.com>
 * Date: 13-6-15
 * Time: 下午4:54
 */

class IndexModule extends Module{
}