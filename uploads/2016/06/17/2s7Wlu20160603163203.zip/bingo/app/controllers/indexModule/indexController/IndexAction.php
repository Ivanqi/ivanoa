<?php
/**
 * User: toozy <toozy@foxmail.com>
 * Date: 13-6-15
 * Time: 下午4:56
 */

class IndexAction  extends Action{
    public function init(){
        $this->title = '首页-'.Bingo::$name;
        return $this;
    }
}