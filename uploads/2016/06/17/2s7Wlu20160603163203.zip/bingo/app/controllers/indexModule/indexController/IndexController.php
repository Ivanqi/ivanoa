<?php
/**
 * User: toozy <toozy@foxmail.com>
 * Date: 13-6-15
 * Time: 下午4:55
 */

class IndexController  extends  Controller{

}