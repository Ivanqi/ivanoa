<?php
/**
 * User: toozy <toozy@foxmail.com>
 * Date: 13-7-9
 * Time: 下午5:53
 */
class HelloAction extends Action{
}