<?php
/**
 * User: toozy <toozy@foxmail.com>
 * Date: 13-7-9
 * Time: 下午5:37
 */
class UserController extends Controller{
}