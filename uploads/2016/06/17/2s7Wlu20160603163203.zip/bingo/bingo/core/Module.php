<?php
/**
 * User: toozy <toozy@foxmail.com>
 * Date: 13-6-9
 * Time: 下午1:59
 */
class Module{
    protected $_global = array();
    public function __construct(){
        foreach ($this->_global as $k=>$v) {
            Bingo::g($k,$v);
        }
    }
    protected function _before(){

    }
    protected function _after(){

    }
    public function execute(){
        $this->_before();
        Bingo::c($this)->execute();
        $this->_after();
    }
}