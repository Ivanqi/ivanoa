<?

?>
<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>oh,出错了</title>
</head>
<body>
<pre>
类型:<?=$type?><br >
文件名:<?=$file?><br >
行数:<?=$line?><br >
信息:<?=$message?><br />
    <? if(isset($backtrace)): ?>
        <hr >
        <? print_r($backtrace); ?>
    <? endif; ?>
</body>
</html>