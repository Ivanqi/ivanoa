<?php
/**
 * @notice 正式环境下请将Bingo和app目录移至web不能直接访问的地方
 * 1.php对gpc的魔术转化不要开。我都是不开的，懒得处理这个
 * 2.采用utf-8编码开发，请勿用于非utf-8编码环境
 * 3.php版本5.3以上
 * 4.我使用nginx
 * 5.短标签的支持是必须的
 */
require 'bingo/core/Bingo.php';
Bingo::run(realpath('app'));